package com.example.stats.data;

public class PlayerStats {

    private int kills;
    private int deaths;
    private int blocksBroken;
    private int blocksPlaced;
    private long playtime;

    public PlayerStats(int kills, int deaths, int blocksBroken, int blocksPlaced, long playtime) {
        this.kills = kills;
        this.deaths = deaths;
        this.blocksBroken = blocksBroken;
        this.blocksPlaced = blocksPlaced;
        this.playtime = playtime;
    }

    public int getKills() { return kills; }
    public void setKills(int kills) { this.kills = kills; }

    public int getDeaths() { return deaths; }
    public void setDeaths(int deaths) { this.deaths = deaths; }

    public int getBlocksBroken() { return blocksBroken; }
    public void setBlocksBroken(int blocksBroken) { this.blocksBroken = blocksBroken; }

    public int getBlocksPlaced() { return blocksPlaced; }
    public void setBlocksPlaced(int blocksPlaced) { this.blocksPlaced = blocksPlaced; }

    public long getPlaytime() { return playtime; }
    public void setPlaytime(long playtime) { this.playtime = playtime; }
}

package com.example.stats.placeholder;

import com.example.stats.data.PlayerStats;
import com.example.stats.data.StatsManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class StatsExpansion extends PlaceholderExpansion {

    private final StatsManager manager;

    public StatsExpansion(StatsManager manager) {
        this.manager = manager;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "stats";
    }

    @Override
    public @NotNull String getAuthor() {
        return "StatsPlugin";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        PlayerStats stats = manager.getStats(player.getUniqueId());

        return switch (params.toLowerCase()) {
            case "kills" -> String.valueOf(stats.getKills());
            case "deaths" -> String.valueOf(stats.getDeaths());
            case "kdr" -> {
                if (stats.getDeaths() == 0) yield stats.getKills() + ".0";
                yield String.format("%.2f", (double) stats.getKills() / stats.getDeaths());
            }
            case "blocks_broken" -> String.valueOf(stats.getBlocksBroken());
            case "blocks_placed" -> String.valueOf(stats.getBlocksPlaced());
            case "ping" -> player.getPing() + "ms";
            case "cords", "coords" ->
                    "X: " + player.getLocation().getBlockX()
                            + " Y: " + player.getLocation().getBlockY()
                            + " Z: " + player.getLocation().getBlockZ();
            case "cords_x", "coords_x" -> String.valueOf(player.getLocation().getBlockX());
            case "cords_y", "coords_y" -> String.valueOf(player.getLocation().getBlockY());
            case "cords_z", "coords_z" -> String.valueOf(player.getLocation().getBlockZ());
            case "playtime" -> {
                long total = stats.getPlaytime();
                Long joinTime = manager.getJoinTime().get(player.getUniqueId());
                if (joinTime != null) total += (System.currentTimeMillis() - joinTime);
                yield StatsManager.formatPlaytime(total);
            }
            default -> null;
        };
    }
}

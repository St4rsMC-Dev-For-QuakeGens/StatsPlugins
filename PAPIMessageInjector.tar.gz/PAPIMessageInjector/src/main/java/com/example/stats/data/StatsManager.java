package com.example.stats.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StatsManager {

    private final JavaPlugin plugin;
    private final Map<UUID, PlayerStats> statsMap = new HashMap<>();
    private final Map<UUID, Long> joinTimes = new HashMap<>();
    private File file;
    private YamlConfiguration config;

    public StatsManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        file = new File(plugin.getDataFolder(), "stats.yml");
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create stats.yml: " + e.getMessage());
            }
        }
        config = YamlConfiguration.loadConfiguration(file);

        for (String key : config.getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            int kills = config.getInt(key + ".kills");
            int deaths = config.getInt(key + ".deaths");
            int blocksBroken = config.getInt(key + ".blocks-broken");
            int blocksPlaced = config.getInt(key + ".blocks-placed");
            long playtime = config.getLong(key + ".playtime");
            statsMap.put(uuid, new PlayerStats(kills, deaths, blocksBroken, blocksPlaced, playtime));
        }
    }

    public void saveAll() {
        for (Map.Entry<UUID, PlayerStats> entry : statsMap.entrySet()) {
            UUID uuid = entry.getKey();
            PlayerStats stats = entry.getValue();
            String path = uuid.toString();
            config.set(path + ".kills", stats.getKills());
            config.set(path + ".deaths", stats.getDeaths());
            config.set(path + ".blocks-broken", stats.getBlocksBroken());
            config.set(path + ".blocks-placed", stats.getBlocksPlaced());
            config.set(path + ".playtime", stats.getPlaytime());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save stats: " + e.getMessage());
        }
    }

    public PlayerStats getStats(UUID uuid) {
        return statsMap.computeIfAbsent(uuid, k -> new PlayerStats(0, 0, 0, 0, 0));
    }

    // Playtime tracking

    public void onPlayerJoin(Player player) {
        joinTimes.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public void onPlayerQuit(Player player) {
        UUID uuid = player.getUniqueId();
        Long joinTime = joinTimes.remove(uuid);
        if (joinTime != null) {
            long session = System.currentTimeMillis() - joinTime;
            PlayerStats stats = getStats(uuid);
            stats.setPlaytime(stats.getPlaytime() + session);
        }
    }

    // Increment methods

    public void addKill(UUID uuid) {
        getStats(uuid).setKills(getStats(uuid).getKills() + 1);
    }

    public void addDeath(UUID uuid) {
        getStats(uuid).setDeaths(getStats(uuid).getDeaths() + 1);
    }

    public void addBlockBroken(UUID uuid) {
        getStats(uuid).setBlocksBroken(getStats(uuid).getBlocksBroken() + 1);
    }

    public void addBlockPlaced(UUID uuid) {
        getStats(uuid).setBlocksPlaced(getStats(uuid).getBlocksPlaced() + 1);
    }

    public Map<UUID, Long> getJoinTime() {
        return joinTimes;
    }

    // Formatting helpers

    public static String formatPlaytime(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        seconds %= 60;
        minutes %= 60;

        StringBuilder sb = new StringBuilder();
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0) sb.append(minutes).append("m ");
        sb.append(seconds).append("s");
        return sb.toString().trim();
    }
}

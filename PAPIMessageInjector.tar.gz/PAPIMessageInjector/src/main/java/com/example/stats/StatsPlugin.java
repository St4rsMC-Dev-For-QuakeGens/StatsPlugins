package com.example.stats;

import com.example.stats.command.StatsCommand;
import com.example.stats.data.StatsManager;
import com.example.stats.listener.StatsListener;
import com.example.stats.placeholder.StatsExpansion;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class StatsPlugin extends JavaPlugin {

    private StatsManager statsManager;
    private StatsExpansion expansion;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        statsManager = new StatsManager(this);
        statsManager.loadAll();

        getServer().getPluginManager().registerEvents(new StatsListener(statsManager), this);
        getCommand("stats").setExecutor(new StatsCommand(statsManager));

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            expansion = new StatsExpansion(statsManager);
            expansion.register();
            getLogger().info("Registered PlaceholderAPI expansion.");
        } else {
            getLogger().warning("PlaceholderAPI not found — placeholders will be unavailable.");
        }

        int interval = getConfig().getInt("auto-save-interval", 5) * 60 * 20;
        new BukkitRunnable() {
            @Override
            public void run() {
                statsManager.saveAll();
            }
        }.runTaskTimer(this, interval, interval);

        getLogger().info("StatsPlugin enabled.");
    }

    @Override
    public void onDisable() {
        if (statsManager != null) statsManager.saveAll();
        if (expansion != null) expansion.unregister();
        getLogger().info("StatsPlugin disabled.");
    }
}

package com.example.stats.command;

import com.example.stats.data.PlayerStats;
import com.example.stats.data.StatsManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class StatsCommand implements CommandExecutor {

    private final StatsManager manager;

    public StatsCommand(StatsManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        Player target;

        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(Component.text("Console must specify a player: /stats <player>", NamedTextColor.RED));
                return true;
            }
            target = (Player) sender;
        } else {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                return true;
            }
        }

        PlayerStats stats = manager.getStats(target.getUniqueId());
        long sessionPlaytime = stats.getPlaytime();
        Long joinTime = manager.getJoinTime().get(target.getUniqueId());
        if (joinTime != null) {
            sessionPlaytime += (System.currentTimeMillis() - joinTime);
        }

        sender.sendMessage(Component.text("=== " + target.getName() + "'s Stats ===", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("Kills: ", NamedTextColor.GRAY).append(Component.text(stats.getKills(), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Deaths: ", NamedTextColor.GRAY).append(Component.text(stats.getDeaths(), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("K/D: ", NamedTextColor.GRAY).append(Component.text(kdr(stats), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Blocks Broken: ", NamedTextColor.GRAY).append(Component.text(stats.getBlocksBroken(), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Blocks Placed: ", NamedTextColor.GRAY).append(Component.text(stats.getBlocksPlaced(), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Playtime: ", NamedTextColor.GRAY).append(Component.text(StatsManager.formatPlaytime(sessionPlaytime), NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Ping: ", NamedTextColor.GRAY).append(Component.text(target.getPing() + "ms", NamedTextColor.WHITE)));
        sender.sendMessage(Component.text("Coordinates: ", NamedTextColor.GRAY).append(Component.text(coords(target), NamedTextColor.WHITE)));

        return true;
    }

    private String kdr(PlayerStats stats) {
        if (stats.getDeaths() == 0) return stats.getKills() + ".0";
        return String.format("%.2f", (double) stats.getKills() / stats.getDeaths());
    }

    private String coords(Player player) {
        return "X: " + player.getLocation().getBlockX()
                + " Y: " + player.getLocation().getBlockY()
                + " Z: " + player.getLocation().getBlockZ();
    }
}
